//
//  Const.h
//  NSURLSession
//
//  Created by Wolf on 16/5/5.
//  Copyright © 2016年 JieShi. All rights reserved.
//

#ifndef Const_h
#define Const_h


#endif /* Const_h */
